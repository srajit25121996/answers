import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


public class Main {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		FileWriter fw1 = new FileWriter("akshay");
		
		String str = "File copy procedure next Line";
		PrintWriter pw = new PrintWriter("sahil");
		BufferedWriter writer = new BufferedWriter(fw1);
		pw.println(str);
		writer.newLine();
		pw.println(str);
		pw.close();
		
		FileReader fr = new FileReader("sahil");
		BufferedReader br = new BufferedReader(fr);
		
		String copy = new String();
		
		while(br.ready())
			copy = br.readLine();
		
		System.out.println("as" + copy);
		
		PrintWriter pw2 = new PrintWriter("akshay");
		
		pw2.println(copy);

		fw1.close();
		fr.close();
		br.close();
		pw2.close();
		pw2.close();
		
	}
}
