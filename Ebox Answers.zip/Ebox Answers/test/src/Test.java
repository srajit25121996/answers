import java.io.ByteArrayInputStream;

class A implements Runnable{
	public void run(){
		System.out.println("run-a");
	}
}

public class Test{
	public static void main(String... args){
		Scanner sc = new Scanner(System.in);
		ByteArrayInputStream bai = new ByteArrayInputStream(null);
		
		A a = new A();
		Thread t = new Thread(a);
		t.start();
		t.start();
	}
}