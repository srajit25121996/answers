
public class ClaraFUp {

	public static int PossibleThreeDigitSubstrings(String mistype){
		
		int len = mistype.length();
		int div = 0;
		
		if(mistype.length() <= 2)
			return 0;
		
		for(int i = 0; i < len; i++){
			
			if (i == len - 2)
				break;
			int check = Integer.parseInt(mistype.substring(i, i+3));
			
			if(check%4 == 0){
				div++;
			}

		}
		
		return div;
	}
}
