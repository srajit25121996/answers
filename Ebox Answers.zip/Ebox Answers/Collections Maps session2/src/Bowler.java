
public class Bowler {

	private String name;

	//Getter and Setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	//Constructor (String)
	public Bowler(String name) {
		super();
		this.name = name;
	}
	
	
}
