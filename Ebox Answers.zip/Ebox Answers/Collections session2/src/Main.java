import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*		
		//Collections/Generics, Lists / session2/Sum even pos
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList <Integer> runs = new ArrayList<Integer>();
		
		int players = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < players; i++){
			runs.add(Integer.parseInt(sc.nextLine()));
		}
		
		int sum = 0;
		boolean evenFlag = true;
		
		for(int i :runs){
			if(evenFlag == false){
				evenFlag = true;
				sum += i;
			}
			else
				evenFlag = false;
		}
		
		System.out.println(sum);
		*/
		
		/*
		//Collections/Generics, Lists / session2/Odd-even index
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList <Integer> runs = new ArrayList<Integer>();
		
		int players = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < players; i++){
			runs.add(Integer.parseInt(sc.nextLine()));
		}
		
		int sum = 0;
		boolean evenFlag = true;
		
		for(int i :runs){
			if(evenFlag == false){
				evenFlag = true;
				if(i%2 != 0)
					sum += i;
			}
			else{
				evenFlag = false;
				if(i%2 == 0)
					sum += i;
			}
		}
		
		System.out.println(sum);

	*/
		
		
		//Collections/Generics, Lists / session2/Duck - batsman
		
		Scanner sc = new Scanner(System.in);
		ArrayList <String> innings = new ArrayList<String>();
		
		int players = Integer.parseInt(sc.nextLine());
		
		for(int i = 0; i < players; i++)
			innings.add(sc.nextLine());
		
		boolean ducks = false;
		
		for(String str :innings){
			
			String []st = str.split("-");
			
			//Validation
			if(st.length == 3){
				
				if(st[1].equals("0") && st[2].equals("0")){
					System.out.println(st[0]);
					ducks = true;
				}
			}
		}
		
		if(ducks == false)
			System.out.println("No player has scored a duck");
		
	}	

}
