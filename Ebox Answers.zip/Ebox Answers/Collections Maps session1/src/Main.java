import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/*
		//Collections Maps/Session 1/ team by matches played
		
		Scanner sc = new Scanner(System.in);
		
		int teams;
		
		System.out.println("Enter number of teams:");
		teams = Integer.parseInt(sc.nextLine());
		
		ArrayList<Team> teamList = new ArrayList();
		
		for(int i = 0; i < teams; i++){
			
			String name;
			Long numberOfMatches;
			
			System.out.println("Enter team " + (i+1) + " detail");
			System.out.println("Enter Name");
			name = sc.nextLine();
			System.out.println("Enter number of matches");
			numberOfMatches = Long.parseLong(sc.nextLine());
			
			teamList.add(new Team(name, numberOfMatches));
		}
		
		TeamComparator tc = new TeamComparator();
		Collections.sort(teamList, tc);
		
		System.out.println("Team list after sort by number of matches");
		for(Team t :teamList)
			System.out.println(t);
		sc.close();
		*/
		
/*		
		//Collections Maps/Session 1/ Player List based on Name and skill
		
		Scanner sc = new Scanner(System.in);
		
		int players;
		
		System.out.println("Please provide the number of players to be registered");
		players = Integer.parseInt(sc.nextLine());
		
		ArrayList<Player> playerSet = new ArrayList<Player>();
		
		ArrayList<String> skillSet = new ArrayList<String>();
		skillSet.add("All Rounder");
		skillSet.add("Batsman");
		skillSet.add("Bowler");
		
		
		for(int i = 0; i < players; i++){
			
			String name;
			int skillChoice;
			
			System.out.println("Please enter player name");
			name = sc.nextLine();
			System.out.println("Please select the skill of the player");
			
			for(int i1 = 1; i1 <= 3; i1++)
				System.out.println(i1 + "." + skillSet.get(i1-1));
			skillChoice = Integer.parseInt(sc.nextLine());
			
			playerSet.add(new Player(name, skillSet.get(skillChoice-1)));
			
		}
		
		PlayerComparator pc = new PlayerComparator();
		
		Collections.sort(playerSet, pc);
		
		System.out.println("Player Details");
		for(Player p :playerSet)
			System.out.println(p);
		
		sc.close();
		*/
		
/*		
		//Collections Maps/Session 1/ HashMap - Player
		
		Scanner sc = new Scanner(System.in);
		
		HashMap<String, Integer> playerSet = new HashMap<String, Integer>();
		
		//Adding players
		while(true){
			
			String name;
			String wickets;
			
			System.out.println("Enter the player name");
			name = sc.nextLine();
			System.out.println("Enter wickets - seperated by \"|\" symbol.");
			wickets = sc.nextLine();
			
			StringTokenizer st = new StringTokenizer(wickets, "\\|");
			
			playerSet.put(name, st.countTokens());
			
			String cont;
			
			System.out.println("Do you want to add another player (yes/no)");
			cont=sc.nextLine();
			
			if(cont.equalsIgnoreCase("yes"))
				continue;
			else
				break;
			
		}
		
		//Searching players
		while(true){
			
			String name;
			
			System.out.println("Enter the player name to search");
			name = sc.nextLine();

			if(playerSet.containsKey(name)){
				System.out.println("Player name : " + name);
				System.out.println("Wicket Count : " + playerSet.get(name));
			}
			else
				System.out.println("No player found with the name " + name);
			String cont;
			
			System.out.println("Do you want to search another player (yes/no)");
			cont=sc.nextLine();
			
			if(cont.equalsIgnoreCase("yes"))
				continue;
			else
				break;
			
		}
		
		sc.close();
		*/
		
		
		//Collections Maps/Session 1/ HashMap - Player
		
		Scanner sc = new Scanner(System.in);
		
		int players;
		
		System.out.println("Enter the number of players");
		players = Integer.parseInt(sc.nextLine());
		
		TreeMap<Integer, Player> playerMap = new TreeMap<Integer, Player>();
		
		for(int i = 0; i < players; i++){
			
			int capNumber;
			String name;
			String team;
			String skill;
			
			System.out.println("Enter the details of the player " + (i+1));
			capNumber = Integer.parseInt(sc.nextLine());
			name = sc.nextLine();
			team = sc.nextLine();
			skill = sc.nextLine();
			
			Player p = new Player(name, team, skill);
			playerMap.put(capNumber, p);
			
		}
		
		Set<Integer> s = playerMap.keySet();
		System.out.println("Player Details");
		for(int i :s){
			System.out.println(i+"--"+playerMap.get(i));
		}
		sc.close();
		
		
		
		
		
	}

}
