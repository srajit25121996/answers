import java.util.Comparator;

public class TeamComparator implements Comparator<Team>{

	
	//Compare on the basis of matches played
	@Override
	public int compare(Team t1, Team t2) {
		
		// TODO Auto-generated method stub
		return (int) (t1.getNumberOfMatches() - t2.getNumberOfMatches());
	}
	

}
