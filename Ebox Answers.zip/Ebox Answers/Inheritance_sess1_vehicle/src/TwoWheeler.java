
public class TwoWheeler extends Vehicle{

	private boolean kickStartAvailable;

	public boolean isKickStartAvailable() {
		return kickStartAvailable;
	}

	public void setKickStartAvailable(boolean kickStartAvailable) {
		this.kickStartAvailable = kickStartAvailable;
	}

	//Constructor(<super args>, boolean)
	public TwoWheeler(String make, String vehicleNumber, String fuelType, int fuelCapacity, int cc,
			boolean kickStartAvailable) {
		super(make, vehicleNumber, fuelType, fuelCapacity, cc);
		this.kickStartAvailable = kickStartAvailable;
	}
	
	public TwoWheeler(boolean kickStartAvailable) {
		this.kickStartAvailable = kickStartAvailable;
	}

	//Empty constructor
	public TwoWheeler() {
		super();
	}
	
	//Display detailed information
	public void displayDetailInfo(){

		System.out.println("---Detail Information---");
		
		if(kickStartAvailable)
			System.out.println("Kick Start Available:" + "YES");
		else
			System.out.println("Kick Start Available:" + "NO");

	}

	public void dislayBasicInfo(){
	
			System.out.println("---Basic Information---");
			System.out.println("Vehicle Number:" + vehicleNumber);
			System.out.println("Fuel Capacity:" + fuelCapacity);
			System.out.println("Fuel Type:" + fuelType);
			System.out.println("CC:" + cc);
		
	}
	
}
