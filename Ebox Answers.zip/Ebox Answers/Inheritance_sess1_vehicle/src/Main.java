import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner sc = new Scanner(System.in);
		
		Vehicle v;
		
		//Menu
		System.out.println("1.Four Wheeler");
		System.out.println("2.Two Wheeler");
		
		int type;		
		
		String make = new String();
		String vehicleNumber = new String();
		String fuelType = new String();
		int fuelCapacity;
		int cc;
		
		
		System.out.println("Enter Vehicle Type:");
		type = Integer.parseInt(sc.nextLine());
		if(type == 1){
	
			System.out.println("Vehicle Make:");
			make = (sc.nextLine());
			
			System.out.println("Vehicle Number:");
			vehicleNumber = (sc.nextLine());
			
			System.out.println("Fuel Type:\n1.Petrol\n2.Diesel");
			int ft = Integer.parseInt(sc.nextLine());
			if(ft == 1)
				fuelType = ("Petrol");
			else
				fuelType = ("Diesel");
			
			System.out.println("Fuel Capacity:");
			fuelCapacity = (Integer.parseInt(sc.nextLine()));
			
			System.out.println("Engine CC:");
			cc = (Integer.parseInt(sc.nextLine()));
			
			v = new Vehicle(make, vehicleNumber, fuelType, fuelCapacity, cc);
			
			System.out.println("Audio System:");
			String audioSystem = (sc.nextLine());
			System.out.println("Number of Doors:");
			int numberOfDoors = (Integer.parseInt(sc.nextLine()));
			
			
			//Display all details
			v.displayMake();
			v.dislayBasicInfo();
			v = new FourWheeler(make, vehicleNumber, fuelType, fuelCapacity, cc,audioSystem, numberOfDoors);
			v.displayDetailInfo();
			
		}
		else if(type == 2){
			
			System.out.println("Vehicle Make:");
			make = (sc.nextLine());
			
			System.out.println("Vehicle Number:");
			vehicleNumber = (sc.nextLine());
			
			System.out.println("Fuel Type:\n1.Petrol\n2.Diesel");
			int ft = Integer.parseInt(sc.nextLine());
			if(ft == 1)
				fuelType = ("Petrol");
			else
				fuelType = ("Diesel");
			
			System.out.println("Fuel Capacity:");
			fuelCapacity = (Integer.parseInt(sc.nextLine()));
			
			System.out.println("Engine CC:");
			cc = (Integer.parseInt(sc.nextLine()));
			
			System.out.println("Kick Start Available(yes/no):");
			String kickStartAvailable = sc.nextLine();
		//	Vehicle v = new Vehicle(make, vehicleNumber, fuelType, fuelCapacity, cc);
			boolean kst;
			if(kickStartAvailable.equals("yes"))
				kst = (true);
			else
				kst = (false);
			
			v = new TwoWheeler(make, vehicleNumber, fuelType, fuelCapacity, cc,kst);
			//Display all details
			v.displayMake();
			v.dislayBasicInfo();
			v.displayDetailInfo();
		}
		
		/*
		if(v instanceof FourWheeler){
			
			
			
		}
		
		else if(v instanceof TwoWheeler){
			
				
		}*/
		
		//3mar 11 air asia		
		
		sc.close();
		
		
		
	}

}
