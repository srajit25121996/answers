package src;


public class Player {
	private Long playerId;
	  private String playerName;

	  public Player(Long playerId, String playerName) {
	      this.playerId = playerId;
	      this.playerName = playerName;
	  }

	  public Long getPlayerId() {
	      return playerId;
	  }

	  public void setPlayerId(Long playerId) {
	      this.playerId = playerId;
	  }

	  public String getPlayerName() {
	      return playerName;
	  }

	  public void setPlayerName(String playerName) {
	      this.playerName = playerName;
	  }
	 
	  
	  @Override
	  public String toString() {
	      return  playerName ;
	  }
	  
}
