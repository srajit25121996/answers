import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class UserMainCode {
	
	
	
	public static void displayDate(String date) throws ParseException{
		
		String[] dateArray = date.split(" ");
		int dd, mm, yyyy;
		
		
		if(dateArray[0] != null){

			
			SimpleDateFormat given = new SimpleDateFormat("MMMM dd, yyyy");
			Date dt = new Date();
			dt = given.parse(date);
			
			SimpleDateFormat result = new SimpleDateFormat("yyyy-MM-dd");
			
			String returnDate = new String();
			returnDate = result.format(dt);
			System.out.println(returnDate);

		}
		
	}
	
	
	
	public static void displayDateTime(String date) throws ParseException{
		
		SimpleDateFormat given = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dt = new Date();
		dt = given.parse(date);
		
		String destination = new String();
		SimpleDateFormat result = new SimpleDateFormat("dd/MM/yyyy, H:mm:ss");
		destination = result.format(dt);
		
		System.out.println(destination);
	}
	
	
/*	
	public static int displayDay(Date dt) throws ParseException{
		
		int dayOfYear = 0;
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		int year= c.get(Calendar.YEAR);
		
		Date dt2 = new Date();
		String str = new String();
		str = (Integer.valueOf(year)) + "-01-01";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		dt2 = sdf.parse(str);
		
		long diff = dt.getTime() - dt2.getTime();
	    return (int)(diff/(1000*60*60*24) + 1);
		
	}
*/	
	
	public static String displayDay(Date dt) throws ParseException{
		
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		//Date dt = new Date();
		SimpleDateFormat input = new SimpleDateFormat("EEEEE");
		String day = input.format(dt);
		
		
	    return day;
		
	}	
	
	
	public static void displayDetails(String date1, String date2) throws ParseException{
		
		Date dt1 = new Date();
		SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
		
		dt1 = input.parse(date1);
		
		Calendar c1 = Calendar.getInstance();
		c1.setTime(dt1);
		
		Date dt2 = new Date();
		dt2 = input.parse(date2);
		
		Calendar c2 = Calendar.getInstance();
		c2.setTime(dt2);

		
		long yearDiff = TimeUnit.MILLISECONDS.toDays(Math.abs(dt1.getTime() - dt2.getTime()))/365;
		long monthDiff = (TimeUnit.MILLISECONDS.toDays(Math.abs(dt1.getTime() - dt2.getTime()))%365)/31;
		
		
		System.out.println("Difference between " + date1 + " and " + date2 + ": "  + yearDiff + " Years and " + monthDiff + " Months");
	}

}


