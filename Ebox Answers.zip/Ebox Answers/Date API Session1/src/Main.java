import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String date1 = sc.nextLine();
		String date2 = sc.nextLine();
		sc.close();
		
		UserMainCode.displayDetails(date1, date2);

		
		
/*		int day = UserMainCode.displayDay(dt);
		
		if (day == 1)
			System.out.println("Sunday");
		else if (day == 2)
			System.out.println("Monday");
		else if (day == 3)
			System.out.println("Tuesday");
		else if (day == 4)
			System.out.println("Wednesday");
		else if (day == 5)
			System.out.println("Thursday");
		else if (day == 6)
			System.out.println("Friday");
		else if (day == 7)
			System.out.println("Saturday");*/

		
	}

}
