package src;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.text.DateForm;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;



public class GameDAO {

	

public List<Game> getAllGameDetails() throws ClassNotFoundException, SQLException {

       List<Game>Al=new ArrayList<Game>();
       Game game=null;
      try
      {
             
          ResourceBundle rb= ResourceBundle.getBundle("mysql");
          
          String url=rb.getString("db.url");
          String user=rb.getString("db.username");
          String pass=rb.getString("db.password");
          Class.forName("com.mysql.jdbc.Driver");
          Connection con = DriverManager.getConnection(url,user,pass);
  
         //fill your code
         String sql = "select game_date, team_id_1, team_id_2 from game";         
         Statement st = con.createStatement();      
         ResultSet rs = st.executeQuery(sql);
         
         TeamDAO Td = new TeamDAO();
         
         while(rs.next()) {
        	 
        	 Team teamOne = Td.getTeamByID((long)rs.getInt(2));
        	 Team teamTwo = Td.getTeamByID((long)rs.getInt(3));
        	 
        	 java.sql.Date sqlDate = rs.getDate(1);
        	 java.util.Date utilDate = new Date(sqlDate.getTime());
        	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        	 String strDate = sdf.format(utilDate);
        	 
        	 game = new Game(strDate, teamOne, teamTwo);
        	 Al.add(game);
        	 
         }
         
         return Al;
      }
      catch(Exception e) {}
      
      return Al;
         
  }
  
  public void updateTeamDetails(Date gameDate,String team1,String team2) throws ClassNotFoundException, SQLException, ParseException {
    
	  ResourceBundle rb= ResourceBundle.getBundle("mysql");
      
      String url=rb.getString("db.url");
      String user=rb.getString("db.username");
      String pass=rb.getString("db.password");
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);

      //fill your code
      String sql = "update game set team_id_1 = ?, team_id_2 = ? where game_date = ?";
      PreparedStatement pst = con.prepareStatement(sql);
      
      TeamDAO td = new TeamDAO();
      long teamOneId = td.getTeamByName(team1).getTeamId();
      long teamTwoId = td.getTeamByName(team1).getTeamId();
      java.sql.Date sqlDate = new java.sql.Date(gameDate.getTime());
      
      pst.setLong(1, teamOneId);
      pst.setLong(2, teamTwoId);
      pst.setDate(3, sqlDate);
      pst.executeUpdate();
      
  }
  
  public void displayGame(List<Game> gameList){
      System.out.format("%-15s %-30s %-30s\n","Game Date","Team 1","Team 2"); 

      //fill your code
      for(Game g :gameList) 
    	  System.out.format("%-15s %-30s %-30s\n",g.getGameDate(),g.getTeam1().getTeamName(),g.getTeam2().getTeamName());
      
      }
  }
	
