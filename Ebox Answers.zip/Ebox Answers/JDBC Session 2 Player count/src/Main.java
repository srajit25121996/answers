

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main {
    
    public static void main(String ags[]) throws Exception {
        System.out.format("%-25s %s\n","Skill","Players");
        TreeMap<Skill,Integer> skillCountMap = null;
        SkillDAO skillDAOIns = new SkillDAO();
       
        //fill your code
        skillCountMap = skillDAOIns.skillCount();
        

        
        Set<Skill> skillSet = skillCountMap.keySet();
        
        for(Skill s :skillSet){
        	System.out.format("%-25s %s\n",s.getSkillName(),skillCountMap.get(s));
        }
    }
}
