
public class WicketBO {

	public void displayAllWicketDetails(Wicket[] wicketList){
		int len = wicketList.length;
		
		for(int i = 0; i < len; i++){
			if(i == 0)
				System.out.println("Wicket Details");
			System.out.println("Wicket " + (i+1));
			System.out.println("Over:" + wicketList[i].getOver());
			System.out.println("Ball:" + wicketList[i].getBall());
			System.out.println("Wicket Type:" + wicketList[i].getWicketType());
			System.out.println("Player Name:" + wicketList[i].getPlayerName());
			System.out.println("Bowler Name:" + wicketList[i].getBowlerName());
		}
	}
	
	public void displaySpecificWicketDetails(Wicket[] wicketList, String wicketType){
		
		int len = wicketList.length;
		for(int i = 0; i < len; i++){
			
			if(wicketList[i].getWicketType().equals(wicketType)){
				System.out.println("Wicket " + (i+1));
				System.out.println("Over:" + wicketList[i].getOver());
				System.out.println("Ball:" + wicketList[i].getBall());
				System.out.println("Wicket Type:" + wicketList[i].getWicketType());
				System.out.println("Player Name:" + wicketList[i].getPlayerName());
				System.out.println("Bowler Name:" + wicketList[i].getBowlerName());
			}
			
			
		}
	}
	
}
