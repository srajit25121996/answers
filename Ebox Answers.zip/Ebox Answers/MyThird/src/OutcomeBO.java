
public class OutcomeBO {

	public void displayAllOutcomeDetails(Outcome[] outcomeList){
		System.out.println("Outcome Details");
		
		//Header
		System.out.println(String.format("%-20s %-20s %-20s %s", "Status", "Winning Team", "Player Of The Match", "Date"));
		
		//Details
		for(Outcome out: outcomeList)
			System.out.println(out);
	}
	
	public void displaySpecificOutcomeDetails(Outcome[] outcomeList, String date){
		System.out.println("Outcome Details");
		
		//Header
		System.out.println(String.format("%-20s %-20s %-20s %s","Status","Winning Team","Player Of The Match","Date"));
		
		
		//Details
		for(Outcome out: outcomeList){
			
			if(out.getDate().equals(date))
				System.out.println(out);
		}
			
			
	}
}
