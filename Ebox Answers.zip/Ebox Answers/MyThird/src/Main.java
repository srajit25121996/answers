import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
/*		
		//Classes and Objects III/Sess2 / Wicket details
		Scanner sc = new Scanner(System.in);
		
		int wickets;
		System.out.println("Enter the number of wickets");
		wickets = Integer.parseInt(sc.nextLine());
		
		//Array of wickets
		Wicket [] wicketList = new Wicket[wickets];
		
		
		
		for(int i = 0; i < wickets; i++){
			
			String str = new String();
			System.out.println("Enter the details of wicket " + (i+1));
			str = sc.nextLine();
			
			//For storing 5 detail fields of each wicket
			String[] wicketDetails = str.split(",");
			
			wicketList[i] = new Wicket(Long.parseLong(wicketDetails[0]), Long.parseLong(wicketDetails[1]), wicketDetails[2], wicketDetails[3], wicketDetails[4]);
		}
		
		WicketBO wbo = new WicketBO();
		wbo.displayAllWicketDetails(wicketList);
		
		String wicketType = new String();
		System.out.println("Enter the wicket type to be searched");
		wicketType = sc.nextLine();
		wbo.displaySpecificWicketDetails(wicketList, wicketType);
		*/
		
		
		//Classes and Objects III/Sess2 / Outcome details
		
		Scanner sc = new Scanner(System.in);
		
		int numberOfMatches;
		
		System.out.println("Enter the number of matches");
		numberOfMatches = Integer.parseInt(sc.nextLine());
		
		Outcome [] outcomeList = new Outcome[numberOfMatches];
		
		for(int i = 0; i < numberOfMatches; i++){
			
			String date = new String();
			String status = new String();
			String winnerTeam = new String();
			String playerOfMatch = new String();
			
			System.out.println("Enter match " + (i+1) + " details");
			System.out.println("Enter the date");
			date = sc.nextLine();
			System.out.println("Enter the status");
			status = sc.nextLine();
			System.out.println("Enter the winner team");
			winnerTeam = sc.nextLine();
			System.out.println("Enter the player of match");
			playerOfMatch = sc.nextLine();
			
			outcomeList[i] = new Outcome(date, status, winnerTeam, playerOfMatch);
		}
		
		//Display all outcomes
		OutcomeBO obo = new OutcomeBO();
		obo.displayAllOutcomeDetails(outcomeList);
		
		
		//Display specific outcome using date search
		String date = new String();
		System.out.println("Enter the date to be searhed");
		date = sc.nextLine();
		
		obo.displaySpecificOutcomeDetails(outcomeList, date);
		}

}
