import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner sc = new Scanner(System.in);
		
		//Menu
		System.out.println("Circle");
		System.out.println("Square");
		System.out.println("Rectangle");
		
		String name = new String();
		
		System.out.println("Enter the shape name");
		name = sc.nextLine();
		
		if(name.equals("Circle")){
			System.out.println("Enter the radius");
			int rad;
			rad = Integer.parseInt(sc.nextLine());
			Circle sh = new Circle("Circle", rad);
			System.out.println("Area of " + name + " is " + String.format("%.2f", sh.calculateArea()));
		}
		else if(name.equals("Square")){
			System.out.println("Enter the side");
			int s;
			s = Integer.parseInt(sc.nextLine());
			Square sh = new Square("Square", s);
			System.out.println("Area of " + name + " is " + String.format("%.2f", sh.calculateArea()));
		}
		else if(name.equals("Rectangle")){
			System.out.println("Enter the length");
			int l;
			l = Integer.parseInt(sc.nextLine());
			System.out.println("Enter the breadth");
			int b;
			b = Integer.parseInt(sc.nextLine());
			Rectangle sh = new Rectangle("Rectangle", l, b);
			System.out.println("Area of " + name + " is " + String.format("%.2f", sh.calculateArea()));
		}
	}

}
