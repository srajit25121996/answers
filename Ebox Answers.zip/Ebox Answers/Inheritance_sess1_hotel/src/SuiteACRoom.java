
public class SuiteACRoom extends HotelRoom{
	private Integer ratePerSqFeet;

	//Constructor Hardcode Rate Per Square Feet as 15
	public SuiteACRoom(String hotelName, Integer numberOfSqFeet, boolean hasTV, boolean hasWifi) {
		super(hotelName, numberOfSqFeet, hasTV, hasWifi);
		this.ratePerSqFeet = 15;
	}
	//Empty Constructor
	public SuiteACRoom() {
		
	}
	//Getters(overriden) and Setters
	@Override
	public Integer getRatePerSqFeet() {
		// TODO Auto-generated method stub
		if(hasWifi)
			return ratePerSqFeet+2;
		else
			return ratePerSqFeet;
	}

	public void setRatePerSqFeet(Integer ratePerSqFeet) {
		this.ratePerSqFeet = ratePerSqFeet;
	}
	
	/*@Override
	public Integer calculateTariff() {
		// TODO Auto-generated method stub
		return ;
	}
	
*/	
	

}
