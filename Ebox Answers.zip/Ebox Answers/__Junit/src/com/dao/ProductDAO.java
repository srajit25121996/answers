package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dto.Product;
import com.util.*;

//Performing DataBase Access Ops
public class ProductDAO {
	
	//Add product to DataBase
	public boolean AddProduct(Product p) throws SQLException, ClassNotFoundException{
		
		//Extracting values from product object
		int pId = p.getpId();
		String pName = p.getpName();
		double pRate = p.getpRate();
		int pQnt = p.getpQnt();
		int pAmt = p.getpAmt();
		int pCat = p.getpCategory();
		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		
		String sql = "insert into Product (PId, PName, Rate, Qnt, Amt, Category) values(?,?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(sql);
		//Setting values for statement execution
		pst.setInt(1, pId);
		pst.setString(2, pName);
		pst.setDouble(3, pRate);
		pst.setInt(4, pQnt);
		pst.setInt(5, pAmt);
		pst.setInt(6, pCat);
		
		try{
			pst.executeQuery();
			return true;
		}
		catch(Exception e){
			System.out.println(e);
			return false;
		}
	}

	
	//Get Database in ArrayList
	public List<Product> ListAllProducts() throws SQLException, ClassNotFoundException{

		ArrayList<Product> productList = new ArrayList<Product>();
		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		String sql = "select * from Product";
		Statement st = con.createStatement();
		
		//Adding elements from ResultSet to array list
		try{
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()){
				int pId = rs.getInt(1);
				String pName = rs.getString(2);
				double pRate = rs.getDouble(3);
				int pQnt = rs.getInt(4);
				int pAmt = rs.getInt(5);
				int pCat = rs.getInt(6);
				
				productList.add(new Product(pId, pName, pRate, pQnt, pAmt, pCat));
			}
				
			return productList;
		}
		catch(Exception e){
			return null;
		}
	}

	//Search Database using Id or category (overloaded methods)
	//Searching by category
	public List<Product> SearchProducts(String Category) throws SQLException, ClassNotFoundException{

		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		//Searching Category
		String sql = "select * from Product where Category="+Category;
		Statement st = con.createStatement();
		
		//Category of a product may not be unique, hence list
		ArrayList<Product> productList = new ArrayList<Product>();
		
		//Adding elements from ResultSet to array list
		try{
			ResultSet rs = st.executeQuery(sql);
			
			while(rs.next()){
				int pId = rs.getInt(1);
				String pName = rs.getString(2);
				double pRate = rs.getDouble(3);
				int pQnt = rs.getInt(4);
				int pAmt = rs.getInt(5);
				int pCat = rs.getInt(6);
					
				productList.add(new Product(pId, pName, pRate, pQnt, pAmt, pCat));

			}

				
			return productList;
		}
		catch(Exception e){
			return null;
		}
	}
	
	//Search by ID
	public Product SearchProducts(Integer Id) throws SQLException, ClassNotFoundException{

		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		//Searching Id
		String sql = "select * from Product where PId="+Id;
		Statement st = con.createStatement();
		
		//ID of a product MUST be unique, hence singular object
		Product p= new Product();
		
		//returning object found
		try{
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next()){
				int pId = rs.getInt(1);
				String pName = rs.getString(2);
				double pRate = rs.getDouble(3);
				int pQnt = rs.getInt(4);
				int pAmt = rs.getInt(5);
				int pCat = rs.getInt(6);
				p = new Product(pId, pName, pRate, pQnt, pAmt, pCat);
				return p;

			}
			//If no object found
			else
				return p;
		}
		//If error obtained
		catch(Exception e){
			return null;
		}
	}
	
	//Modify Database using pId using Product type object sent as parameter
	public boolean ModifyProducts(Product p) throws SQLException, ClassNotFoundException{

		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		//Searching Category
		String sql = "update Product set PName =?, Rate = ?, Qnt = ?, Amt = ?, Category = ? where PId="+p.getpId();
		PreparedStatement pst = con.prepareStatement(sql);
		
		//Extracting values from product object

		String pName = p.getpName();
		double pRate = p.getpRate();
		int pQnt = p.getpQnt();
		int pAmt = p.getpAmt();
		int pCat = p.getpCategory();
		//Setting parameters
		pst.setString(1, pName);
		pst.setDouble(2, pRate);
		pst.setInt(3, pQnt);
		pst.setInt(4, pAmt);
		pst.setInt(5, pCat);
		
		//Modifying particular object
		try{
			pst.executeUpdate();
			return true;
		}
		catch(Exception e){
			System.out.println(e);
			return false;
		}
	}
	
	//Delete a record from DataBase by pId
	public boolean DeleteProducts(Integer Id) throws SQLException, ClassNotFoundException{

		
		//Database ops
		Connection con = ConnectionUtils.StartConnection();
		//Searching Category
		String sql = "delete from Product where PId="+Id;
		Statement st = con.createStatement();
		
		try{
			st.executeUpdate(sql);
			return true;
		}
		catch(Exception e){
			return false;
		}
	}
	
}
