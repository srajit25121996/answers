package com.presentation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.dto.Product;
import com.service.ProductDBServices;

public class Main {

	public static Product getProduct(){
		
		Scanner sc = new Scanner(System.in);
		
		//Input all attributes
		System.out.print("\nEnter Product Id: ");
		int pId = Integer.parseInt(sc.nextLine());
		System.out.print("\nEnter Product Name: ");
		String pName = sc.nextLine();
		System.out.print("\nEnter Product pRate: ");
		double pRate = Double.parseDouble(sc.nextLine());;
		System.out.print("\nEnter Product quantity: ");
		int pQnt = Integer.parseInt(sc.nextLine());;
		int pAmt = (int) (pQnt*pRate);
		System.out.print("\nEnter Product category Id: ");
		int pCat = Integer.parseInt(sc.nextLine());
		

		
		return new  Product(pId, pName, pRate, pQnt, pAmt, pCat);
	}
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		while(true){
			
			//==========Menu==========//
			System.out.format("%-10s\n", "Menu");
			System.out.println("1. Add a Product");
			System.out.println("2. Modify a Product");
			System.out.println("3. Delete a Product");
			System.out.println("4. Search a Product by Id");
			System.out.println("5. Search Product(s) by Category");
			System.out.println("6. List Product(s)");
			System.out.println("7. Exit");
			
			int choice = 0;
			
			System.out.println("Enter choice: ");
			choice = Integer.parseInt(sc.nextLine());
			//Create a service object to obtain access to DB operations
			ProductDBServices PDBS = new ProductDBServices();
			
			switch(choice){

			
			//Add product to DB
			case 1:
				System.out.println("Product details required");
				Product addP = getProduct();
				boolean add = PDBS.AddProduct(addP);
				if(add)
					System.out.println("Product added successfully");
				else
					System.out.println("Could not add product");
				break;

				
			//Modifying a product based on Id
			case 2:
				System.out.println("Product details required");
				Product modP = getProduct();
				boolean mod = PDBS.ModifyProducts(modP);
				if(mod)
					System.out.println("Product modified successfully");
				else
					System.out.println("Could not modify product");
				break;
				
				
			//Deleting a product using product Id
			case 3:
				System.out.println("Enter the product ID of the product to be deleted");
				int Id = Integer.parseInt(sc.nextLine());
				boolean del = PDBS.DeleteProducts(Id);
				
				if(del)
					System.out.println("Deletion successful!");
				else
					System.out.println("Could not delete");
				break;
				
			//Searching products via Id
			case 4:
				Product p;
				System.out.println("Enter Product Id of product to be searched");
				int Id1 = Integer.parseInt(sc.nextLine());
				p = PDBS.SearchProducts(Id1);
				//If search  could not go through
				if(p == null){
					System.out.println("Could not execute search!");
					break;
				}
				//If search returned no value
				else if(p.getpAmt()<0){
					System.out.println("Could not find any product with given ID");
					break;
				}
				//If found print the product
				System.out.println("Found a product...");
				System.out.println(p);
				break;

				
			//Searching products via category
			case 5:
				System.out.println("Enter Category (Id) of products to be searched");
				String pCat = sc.nextLine();
				ArrayList<Product> productList = (ArrayList<Product>) PDBS.SearchProducts(pCat);
				//Null returned if search could not go through
				if(productList != null){
					System.out.println("Found " + productList.size() + " product(s).");
					for(Product p11 :productList)
						System.out.println(p11);
				}
				else
					System.out.println("Could not execute search!");
				break;
				
				
			//Listing all products
			case 6: 
				ArrayList<Product> productList1 = new ArrayList<Product>();
				productList1 = (ArrayList<Product>) PDBS.ListAllProducts();
				//Checking if table had products 
				if(productList1.size() == 0){
					System.out.println("No Products listed");
					break;
				}
				//Printing if products found
				for(Product p11 :productList1)
					System.out.println(p11);
				break;
				
			//Exiting
			case 7:
				System.out.println(" ...Exiting... ");
				System.exit(0);
				
			//Invalid choice
			default: 
				System.out.println("Invalid choice, enter 7 to exit");
				continue;
			
			}
			
		
		}
	}

}
