package com.dto;

//Database transaction object
public class Product {

	Integer pId;
	String pName;
	Double pRate;
	Integer pQnt;
	Integer pAmt;
	Integer pCategory;
	
	//Constructor (Integer, String, IntegerX4)
	public Product(Integer pId, String pName, Double pRate, Integer pQnt, Integer pAmt, Integer pCategory) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pRate = pRate;
		this.pQnt = pQnt;
		this.pAmt = pAmt;
		this.pCategory = pCategory;
	}

	//Empty Constructor
	public Product() {
		super();
		//Flag for no product found
		this.pAmt = -1;
	}


	//Getters and Setters
	public Integer getpId() {
		return pId;
	}

	public void setpId(Integer pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public Double getpRate() {
		return pRate;
	}

	public void setpRate(Double pRate) {
		this.pRate = pRate;
	}

	public Integer getpQnt() {
		return pQnt;
	}

	public void setpQnt(Integer pQnt) {
		this.pQnt = pQnt;
	}
	
	public Integer getpAmt() {
		return pAmt;
	}

	public void setpAmt(Integer pAmt) {
		this.pAmt = pAmt;
	}

	public Integer getpCategory() {
		return pCategory;
	}

	public void setpCategory(Integer pCategory) {
		this.pCategory = pCategory;
	}

	@Override
	public String toString() {
		return "Product [pId=" + pId + ", pName=" + pName + ", pRate=" + pRate + ", pAmt=" + pAmt + ", pCategory="
				+ pCategory + "]";
	}
	
	
	
	
	
}
