package com.service;

import java.sql.SQLException;
import java.util.List;
import com.dao.ProductDAO;
import com.dto.Product;


//Providing services to presentation (Main) layer
public class ProductDBServices {
		
		//Add product to DataBase
		public boolean AddProduct(Product p) throws SQLException, ClassNotFoundException{
			
			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.AddProduct(p);
			
		}
		//Get Database in ArrayList
		public List<Product> ListAllProducts() throws SQLException, ClassNotFoundException{

			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.ListAllProducts();
		}

		//Search Database using Id or category (overloaded services)
		//Searching by category
		public List<Product> SearchProducts(String Category) throws SQLException, ClassNotFoundException{

			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.SearchProducts(Category);
		}
		
		//Search by ID
		public Product SearchProducts(int Id) throws SQLException, ClassNotFoundException{

			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.SearchProducts(Id);
			
		}
		
		//Modify Database using pId using Product type object sent as parameter
		public boolean ModifyProducts(Product p) throws SQLException, ClassNotFoundException{

			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.ModifyProducts(p);
			
		}
		
		//Delete a record from DataBase by pId
		public boolean DeleteProducts(int Id) throws SQLException, ClassNotFoundException{

			//Product manipulation object
			ProductDAO pdao = new ProductDAO();
			return pdao.DeleteProducts(Id);
	}

}
