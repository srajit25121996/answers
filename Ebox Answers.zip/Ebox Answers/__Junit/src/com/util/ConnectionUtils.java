package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionUtils {

	public static Connection StartConnection() throws SQLException, ClassNotFoundException{
    ResourceBundle rb= ResourceBundle.getBundle("mysql");
    
    String url=rb.getString("db.url");
    String user=rb.getString("db.username");
    String pass=rb.getString("db.password");
    Class.forName("oracle.jdbc.driver.OracleDriver");
       
    Connection con = DriverManager.getConnection(url,user,pass);
    
    return con;
	}
}
