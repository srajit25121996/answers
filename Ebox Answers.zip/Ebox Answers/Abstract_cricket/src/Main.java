import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		Scanner sc = new Scanner(System.in);
		
		//Creating instances
		Match match = null;
		ODIMatch odiMatch;
		TestMatch testMatch;
		T20Match t20Match;
		
		System.out.println("Enter the Cricket Format");
		System.out.println("1.ODI");
		System.out.println("2.T20");
		System.out.println("3.Test");
		
		int format;
		format = Integer.parseInt(sc.nextLine());
		
	    if(format == 1)
	    	match = new ODIMatch();
	    else if(format == 2)
	    	match = new T20Match();
	    else if(format == 3)
	    	match = new TestMatch();
	    else{
	    	System.out.println("Invalid Format type");
	    	System.exit(0);
	    }
	    
		int currentScore;
		float currentOver;
		int target;
		
		System.out.println("Enter the Current Score");
		currentScore = Integer.parseInt(sc.nextLine());
	    System.out.println("Enter the Current Over");
	    currentOver = Float.parseFloat(sc.nextLine());
	    System.out.println("Enter the Target Score");
	    target = Integer.parseInt(sc.nextLine());
	    

	    
	    match.setCurrentOver(currentOver);
	    match.setCurrentScore(currentScore);
	    match.setTarget(target);
	    
	    //Display
	    double reqRunRate = match.calculateRunrate();
		int balls = match.calculateBalls();
		match.display(reqRunRate, balls);
	}

}


