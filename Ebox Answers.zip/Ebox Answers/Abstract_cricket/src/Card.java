
public class Card {

    protected String holderName;
    protected String cardNumber;
    protected String expiryDate;

      
}
