  
public class TestMatch extends Match{

	@Override
	public float calculateRunrate() {
		// TODO Auto-generated method stub
		float rr;
		rr = (this.getTarget() - this.getCurrentScore())/((90 - this.getCurrentOver()));
		return rr;
	}

	@Override
	public int calculateBalls() {
		// TODO Auto-generated method stub
		int ballsLeft = (int) ((90 - this.getCurrentOver()) * 6);
		return ballsLeft;
	}

	
}


