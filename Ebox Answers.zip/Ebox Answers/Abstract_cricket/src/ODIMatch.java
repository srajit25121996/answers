  
public class ODIMatch extends Match{

	@Override
	public float calculateRunrate() {
		// TODO Auto-generated method stub
		float rr;
		rr = (this.getTarget() - this.getCurrentScore())/((50 - this.getCurrentOver()));
		return rr;
	}

	@Override
	public int calculateBalls() {
		// TODO Auto-generated method stub
		int ballsLeft = (int) ((50 - this.getCurrentOver()) * 6);
		return ballsLeft;
	}

}


