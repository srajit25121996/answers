
public class MembershipCard {
    private Integer rating;

    
    
}
