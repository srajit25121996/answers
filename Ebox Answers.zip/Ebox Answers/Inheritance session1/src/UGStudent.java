class UGStudent extends Student
{
	private String degree;
	private String stream;
	/*FILL CODE HERE*/
	
	//Getters and Setters
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	
	//Constructor(<super args>, String, String)
	public UGStudent(String name, String id, int age, double grade, String address, String degree, String stream) {
		super(name, id, age, grade, address);
		this.degree = degree;
		this.stream = stream;
	}
	
	
	//Check passing status
	boolean isPassed(){
		if(grade>=70)
			return true;
		else
			return false;
	}
	
	
	//Display details of a Student
	void display(){
		
//		System.out.println("Student details");
		System.out.println("Name : " + name);
		System.out.println("Id : " + id);
		System.out.println("Age : " + age);
		System.out.println("Grade : " + grade);
		System.out.println("Address : " + address);
		System.out.println("Degree : " + degree);
		System.out.println("Stream : " + stream);
		/*if(this.isPassed())
			System.out.println("Result : " + "Pass");
		else
			System.out.println("Reasult : " + "Fail");*/
		
	}
	
	
	
}
	
