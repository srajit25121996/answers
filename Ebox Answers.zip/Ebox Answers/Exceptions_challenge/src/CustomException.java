
public class CustomException extends Exception {

	public CustomException(String errMsg){
		System.out.println(errMsg);
	}
}
