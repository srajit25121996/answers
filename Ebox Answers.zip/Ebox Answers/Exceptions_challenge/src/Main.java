class Demo
{
int a, b;
demo()
{
a = 10;
b = 20;
}
public void print()
{
System.out.print("a = " + a + " b = " + b + " ");
}
}

class Test {
public static void main(String[] args) {
demo obj1 = new demo();
demo obj2 = obj1;
obj1.a += 1;
obj1.b += 1;
obj1.print();
obj2.print();
}
}