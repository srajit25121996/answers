

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class GameDAO {
  
  
	public List<Game> listGame(Date gameDate) throws SQLException, ClassNotFoundException
	{

		Connection con = null;

		ResourceBundle rb = ResourceBundle.getBundle("mysql");
        String url = rb.getString("db.url");
        String user = rb.getString("db.username");
        String pass = rb.getString("db.password");

        try {
        	Class.forName("com.mysql.jdbc.Driver");
            } 
        catch (ClassNotFoundException ex) {
        	Logger.getLogger(GameDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        con = DriverManager.getConnection(url,user,pass);
          
        

        //fill your code
        String sql = "select outcome_id from game where game_date=?";
        PreparedStatement st = con.prepareStatement(sql);
        java.sql.Date sdate = new java.sql.Date(gameDate.getTime());
        st.setDate(1, sdate);
        ResultSet rs = st.executeQuery();
        
        OutComeDAO ocDAO = new OutComeDAO();
        ArrayList<Game> gameList = new ArrayList<Game>();
        
        while(rs.next()){
        	OutCome oc = ocDAO.getOutComeByID(rs.getLong(1) + 1);
        	gameList.add(new Game(gameDate, oc));
        }
        
        return gameList;
        
        
      }
  }



