
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;




public class VenueDAO{
	
public Venue getVenueByID(Long id) throws ClassNotFoundException, SQLException {
    ResourceBundle rb= ResourceBundle.getBundle("mysql");
    
    String url=rb.getString("db.url");
    String user=rb.getString("db.username");
    String pass=rb.getString("db.password");
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection(url,user,pass);

    //fill your code
    String sql = "select name from venue where id="+id;
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery(sql);
    rs.next();
    return new Venue(id, rs.getString(1));    		

 }

public Venue getVenueByName(String name) throws ClassNotFoundException, SQLException {
    ResourceBundle rb= ResourceBundle.getBundle("mysql");
    
    String url=rb.getString("db.url");
    String user=rb.getString("db.username");
    String pass=rb.getString("db.password");
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection(url,user,pass);

    //fill your code
    String sql = "select id from venue where name='"+name+"'";
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery(sql);
    rs.next();
    return new Venue(rs.getLong(1), name);   
 }

}
