

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;



public class GameDAO {

	

public List<Game> getAllGameDetails() throws ClassNotFoundException, SQLException {

       List<Game>Al=new ArrayList<Game>();
       Game game = new Game();
      try
      {
             
          ResourceBundle rb= ResourceBundle.getBundle("mysql");
          
          String url=rb.getString("db.url");
          String user=rb.getString("db.username");
          String pass=rb.getString("db.password");
          Class.forName("com.mysql.jdbc.Driver");
          Connection con = DriverManager.getConnection(url,user,pass);
       
          //fill your code
          String sql = "select game_date, venue_id from game";
          Statement st = con.createStatement();
          ResultSet rs = st.executeQuery(sql);
          
          VenueDAO vdao = new VenueDAO();
          
          while(rs.next()){
        	  java.util.Date gameDate = new java.util.Date(rs.getDate(1).getTime());
        	  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        	  long venueId = rs.getLong(2);
        	  Venue v = vdao.getVenueByID(venueId);
        	  game = new Game(sdf.format(gameDate), v);
        	  Al.add(game);
          }
          
          return Al;
      }
      catch(Exception e){}
      
      return Al;

  }
  
  public void updateVenueDetails(Date gameDate, String venue) throws ClassNotFoundException, SQLException, ParseException {
    
	  ResourceBundle rb= ResourceBundle.getBundle("mysql");
      
      String url=rb.getString("db.url");
      String user=rb.getString("db.username");
      String pass=rb.getString("db.password");
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager.getConnection(url,user,pass);
      VenueDAO venueIns=new VenueDAO();
      Long venueId=venueIns.getVenueByName(venue).getVenueId();
      
      //fill your code
      String sql = "update game set venue_id=? where game_date=?";
      PreparedStatement pst = con.prepareStatement(sql);
      
      java.sql.Date sdate = new java.sql.Date(gameDate.getTime());
      pst.setDouble(1, (venueId));
      pst.setDate(2, sdate);
      
      pst.executeUpdate();      
      
  }
  
  
  public void displayGame(List<Game> gameList){
      System.out.format("%-15s %-30s\n","Game Date","Venue"); 

      //fill your code
      for(Game g :gameList)
    	  System.out.format("%-15s %-30s\n", g.getGameDate(), g.getVenue().getVenueName()); 
  }
	
}
