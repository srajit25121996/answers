
public class Player {
	public String name;
	public Long runs;
	
	//Constructor (String, Long)
	public Player(String name, Long runs) {
		super();
		this.name = name;
		this.runs = runs;
	}

	//Empty Constructor
	public Player() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getRuns() {
		return runs;
	}

	public void setRuns(Long runs) {
		this.runs = runs;
	}
	
	

}
