
public class Revenue implements Comparable<Revenue>{

	private String category;
	private String amount;
	
	//Getters and Setters
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	//Constructor (String, String)
	public Revenue(String category, String amount) {
		super();
		this.category = category;
		this.amount = amount;
	}
	
	//Empty Constructor
	public Revenue() {
		super();
	}
	
	
	@Override
	public int compareTo(Revenue r) {
		// TODO Auto-generated method stub


		if (Integer.parseInt(this.amount) == Integer.parseInt(r.getAmount())) {
            return 0;
        } else if (Integer.parseInt(this.amount) < Integer.parseInt(r.getAmount())) {
            return -1;
        }
        return 1;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%-15s%-15s", category, amount);
	}
	
	
	
}
