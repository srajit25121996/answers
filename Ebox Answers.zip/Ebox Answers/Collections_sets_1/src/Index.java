
public class Index implements Comparable<Index>{

	Character ch;
	Integer count;
	
	//Getters and Setters
	public Character getCh() {
		return ch;
	}
	public void setCh(Character ch) {
		this.ch = ch;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
	//Constructor (String, int)
	public Index(Character ch, Integer count) {
		super();
		this.ch = ch;
		this.count = count;
	}
	
	
	@Override
	public int compareTo(Index i) {
		
		// TODO Auto-generated method stub
		if ((this.ch) == (i.getCh())) {
            return 0;
        } else if ((this.ch) <(i.getCh())) {
            return -1;
        }
        return 1;

	}
	
	
}
