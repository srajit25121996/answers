import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		//Collections/Sets/Session1/HashSet1
		
		Scanner sc = new Scanner(System.in);
		
		int players = Integer.parseInt(sc.nextLine());
		
		TreeSet<String> playerList = new TreeSet<String>();
		
		for(int i = 0; i < players; i++){
			playerList.add(sc.nextLine());
		}
	
		System.out.println(playerList.size());
		
		sc.close();
		*/
		
		
/*
		//Collections/Sets/Player of the Match
		
		Scanner sc = new Scanner(System.in);
		
		int players = Integer.parseInt(sc.nextLine());
		
		TreeSet<String> playerList = new TreeSet<String>();
		
		for(int i = 0; i < players; i++)
			playerList.add(sc.nextLine());
	
		Iterator it = playerList.iterator();
		
		while(it.hasNext())
			System.out.println(it.next());
		
		
		sc.close();
		*/
		
		
		/*
		//Collections/Sets/Set - Revenue Manager
		
				Scanner sc = new Scanner(System.in);
				
				TreeSet<Revenue> revenueList = new TreeSet<Revenue>();
				
				while(true){
					
					String category;
					String revenue;
					
					System.out.println("Enter revenue category");
					category = sc.nextLine();
					System.out.println("Enter revenue amount");
					revenue = sc.nextLine();
					
					revenueList.add(new Revenue (category, revenue));
					
					String choice;
					System.out.println("Do you want to continue(yes/no):");
					choice = sc.nextLine();
					
					if(choice.equals("yes"))
						continue;
					else
						break;
				}
				
				System.out.println("Top spending categories");
			
				Iterator<Revenue> it = revenueList.descendingIterator();
				
				long total = 0;
				
				Revenue temp;
				
				System.out.println(String.format("%-15s%-15s", "Category", "Amount"));
				
				while(it.hasNext()){
					
					temp = it.next();
					System.out.println(temp);
					total = total + Long.parseLong(temp.getAmount());
					
				}
					
				System.out.println("Total amount earned: " + total);
				
				sc.close();
		*/
		
		
		/*
		//Collections/Sets/Set - Player List Index Builder
		Scanner sc = new Scanner(System.in);
		
		HashSet<Player> playerSet= new HashSet<Player>();
		
		//Input loop
		while(true){
			
			boolean namePresence = false;
			
			String name;
			String skill;
			
			System.out.println("Enter Player Name:");
			name = sc.nextLine();
			System.out.println("Enter Skill:");
			skill = sc.nextLine();
			
			Iterator<Player> it = playerSet.iterator();
			
			//Does player exist or not
			while(it.hasNext()){
				Player p = it.next();
				if(p.getName().equals(name)){
					namePresence = true;
					System.out.println("Player " + name + " already exist");
				}
					
			}
			
			//Add to hashset if player name does not exist
			if(namePresence != true)
				playerSet.add(new Player(name, skill));
			
			
			String choice;
			System.out.println("Do you want to continue(yes/no):");
			choice = sc.nextLine();
			
			if(choice.equalsIgnoreCase("no"))
				break;
			else				
				continue;
					
		}
		
		TreeSet<Index> ts = IndexBuilder.buildIndex(playerSet);
		System.out.println(String.format("%-14s%-15s", "Player", "Index"));
		IndexBuilder.displayIndex(ts);
		*/
		
		/*
		//Collections/Sets/Session1 Difference
		
		Scanner sc = new Scanner(System.in);
		
		int s4, s5;
		
		System.out.println("Enter the number of best bowlers in season 4");
		s4 = Integer.parseInt(sc.nextLine());
		
		
		HashSet<String> s4List = new HashSet<String>();
		
		//Input
		System.out.println("Enter the name of players");
		for(int i = 0; i < s4; i++)
			s4List.add(sc.nextLine());
		
		System.out.println("Enter the number of best bowlers in season 5");
		s5 = Integer.parseInt(sc.nextLine());
		
		
		HashSet<String> s5List = new HashSet<String>();
		
		//Input
		System.out.println("Enter the name of players");
		for(int i = 0; i < s5; i++)
			s5List.add(sc.nextLine());
		
		//Output s4
		System.out.println("Player Set 1");
		for(String str :s4List)
			System.out.println(str);
		
		//Output s5
		System.out.println("Player Set 2");
		for(String str :s5List)
			System.out.println(str);
		
		//Inconsistent Players in s4
		System.out.println("Difference");
		//s4List.removeAll(s5List);
		for(String str :s4List){
			if(s5List.contains(str))
				continue;
			else
				System.out.println(str);
		}
			
		
		sc.close();
		*/
		
	/*	
		//Collections/Sets/Session1 Union
		
		Scanner sc = new Scanner(System.in);
		
		int s4, s5;
		
		System.out.println("Enter the number of top run scorers in season 4");
		s4 = Integer.parseInt(sc.nextLine());
		
		
		HashSet<String> s4List = new HashSet<String>();
		
		//Input
		System.out.println("Enter the name of players");
		for(int i = 0; i < s4; i++)
			s4List.add(sc.nextLine());
		
		System.out.println("Enter the number of top run scorers in season 5");
		s5 = Integer.parseInt(sc.nextLine());
		
		
		HashSet<String> s5List = new HashSet<String>();
		
		//Input
		System.out.println("Enter the name of players");
		for(int i = 0; i < s5; i++)
			s5List.add(sc.nextLine());
		
		//Output s4
		System.out.println("Player Set 1");
		for(String str :s4List)
			System.out.println(str);
		
		//Output s5
		System.out.println("Player Set 2");
		for(String str :s5List)
			System.out.println(str);
		
		//Players in s4 and s5
		System.out.println("Union");
		s4List.addAll(s5List);
		for(String str :s4List){
			System.out.println(str);
		}
			
		
		sc.close();
		*/
		
		/*
		//Collections/Sets/Session1 Intersection
		
				Scanner sc = new Scanner(System.in);
				
				int s4, s5;
				
				System.out.println("Enter the number of top run scorers in season 4");
				s4 = Integer.parseInt(sc.nextLine());
				
				
				HashSet<String> s4List = new HashSet<String>();
				
				//Input
				System.out.println("Enter the name of players");
				for(int i = 0; i < s4; i++)
					s4List.add(sc.nextLine());
				
				System.out.println("Enter the number of top run scorers in season 5");
				s5 = Integer.parseInt(sc.nextLine());
				
				
				HashSet<String> s5List = new HashSet<String>();
				
				//Input
				System.out.println("Enter the name of players");
				for(int i = 0; i < s5; i++)
					s5List.add(sc.nextLine());
				
				//Output s4
				System.out.println("Player Set 1");
				for(String str :s4List)
					System.out.println(str);
				
				//Output s5
				System.out.println("Player Set 2");
				for(String str :s5List)
					System.out.println(str);
				
				//Players in s4 and s5
				System.out.println("Intersection");
				s4List.retainAll(s5List);
				for(String str :s4List){
					System.out.println(str);
				}
					
				
				sc.close();
				*/
		

		
		
	}		

}
