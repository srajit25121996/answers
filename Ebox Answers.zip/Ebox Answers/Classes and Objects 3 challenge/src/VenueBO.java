 class VenueBO {
    
    void displayKabbadiVenueDetails(Venue venue)
    {
        //fill your code
    	System.out.println("Venue Details");
    	String str = venue.toString();
    	System.out.println(str);
    }

}
