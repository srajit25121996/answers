
public class InternationalPlayer extends Player{
	
	private String capNumber;
	private Long noOfTestAppearance;
	private Long noOfODIAppearance;
	
	//Getters and Setters
	public String getCapNumber() {
		return capNumber;
	}
	public void setCapNumber(String capNumber) {
		this.capNumber = capNumber;
	}
	public Long getNoOfTestAppearance() {
		return noOfTestAppearance;
	}
	public void setNoOfTestAppearance(Long noOfTestAppearance) {
		this.noOfTestAppearance = noOfTestAppearance;
	}
	public Long getNoOfODIAppearance() {
		return noOfODIAppearance;
	}
	public void setNoOfODIAppearance(Long noOfODIApperance) {
		this.noOfODIAppearance = noOfODIAppearance;
	}
	
	//Constructor (<super args>, String, Long X2)
	public InternationalPlayer(String name, String country, String capNumber, Long noOfTestAppearance,
			Long noOfODIAppearance) {
		super(name, country);
		this.capNumber = capNumber;
		this.noOfTestAppearance = noOfTestAppearance;
		this.noOfODIAppearance = noOfODIAppearance;
	}
	
	
	public void displayDetails(){
		System.out.println("Player Details:");
		System.out.println("Player name : " + name);
		System.out.println("Country : " + country);
		System.out.println("Cap number : " + capNumber);
		System.out.println("Number of test appearnace : " + noOfTestAppearance);
		System.out.println("Number of ODI appearnace : " + noOfODIAppearance);
	}
}
