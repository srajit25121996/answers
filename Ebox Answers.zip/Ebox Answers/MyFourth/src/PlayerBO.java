
public class PlayerBO {
	
	public Player createPlayer(String data, Team[] teamList){
		
		String playerName = data.split(",")[0];
		String playerTeam = data.split(",")[1];
		
		Player p = new Player();
		p.setName(playerName);
		
		for(Team t: teamList){
			if(t.getName().equals(playerTeam))
				p.setTeam(t);
		}
		return p;
	}
	
	
	public String findTeamName(Player[] playerList, String playername){
		
		for(Player p: playerList){
			if(p.getName().equals(playername)){
				return p.getTeam().getName();
			}			
		}
		
		return "asd";
	}
	
	public boolean findWhetherPlayersAreInSameTeam(Player[] playerList, String playername1, String playername2){
		Team playerTeam1 = new Team();
		Team playerTeam2 = new Team();
		
		for(Player p: playerList){
			if(p.getName().equals(playername1)){
				playerTeam1 = p.getTeam();
				break;
			}
		}
		
		for(Player p: playerList){
			if(p.getName().equals(playername2)){
				playerTeam2 = p.getTeam();
				break;
			}
		}
		
		if(playerTeam1.equals(playerTeam2))
			return true;
		else
			return false;
	}

}
