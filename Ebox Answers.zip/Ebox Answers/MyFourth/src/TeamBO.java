
public class TeamBO {

	public Team createTeam(String data){
		Team returnTeam = new Team(data.split(",")[0], data.split(",")[1]);
		return returnTeam;
	}
}
