
public class Innings {

	private String _battingTeam;
	private Long _runs;
	
	//Constructor (String, Long)
	public Innings(String _battingTeam, Long _runs) {
		super();
		this._battingTeam = _battingTeam;
		this._runs = _runs;
	}
	
	//Getters and Setters
	public String get_battingTeam() {
		return _battingTeam;
	}
	public void set_battingTeam(String _battingTeam) {
		this._battingTeam = _battingTeam;
	}
	public Long get_runs() {
		return _runs;
	}
	public void set_runs(Long _runs) {
		this._runs = _runs;
	}
	@Override
	public String toString() {
		return  String.format("%-19s %s", _battingTeam, _runs);
	}
	
	
}
