
public class Triangle extends Figure{

	public Triangle(double dim1, double dim2) {
		super(dim1, dim2);
		// TODO Auto-generated constructor stub
	}
	public double area(){
		if(this instanceof Triangle){
			return (0.5* dim1 * dim2);
		}
		return 0;
	}

}
