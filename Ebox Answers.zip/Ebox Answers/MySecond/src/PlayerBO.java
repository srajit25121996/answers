
public class PlayerBO {
	
	//Display player details
	public void displayPlayerDetails(Player player){
		String str = String.format("%-15s %-15s %-15s", player.getName(), player.getCountry(), player.getSkill());
		System.out.println("Player Details\n" + player);
	}
}
