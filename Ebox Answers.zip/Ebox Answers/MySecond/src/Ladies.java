
public class Ladies extends Compartment{

	public void notice(){
		System.out.println("Ladies compartment");
	}
}
