
public class InningsBO {
	
	public void DisplayAllInningsDetails(Innings[] inningsList){
		
		System.out.println("Innings Details");
		for(Innings inn: inningsList)
			System.out.println(inn);
	}
}
