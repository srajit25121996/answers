import java.util.StringTokenizer;

public class UserMainCode {

	/*
	//String buff_sess1/player-team
	public static void display(String player, String team){
		StringBuffer details = new StringBuffer();
		details.append(player);
		details.append("#");
		details.append(team);
		System.out.println(details);
	}
	*/
	
	/*
	//String buff_sess1/String Builder
	public static void display(String fname, String lname){
		
		StringBuilder fullName = new StringBuilder();
		fullName.append(((String) fname.subSequence(0,1)).toUpperCase());
		fullName.append(((String) fname.substring(1)).toLowerCase());
		fullName.append(" ");
		fullName.append(lname.toUpperCase());

		System.out.println(fullName);
		
	}
*/	
	
	
/*	
	//String buff_sess1/String tokenizer 2
	public static void display(String teamList){
		StringTokenizer st = new StringTokenizer(teamList, "#");
		System.out.println("Number of teams : " + st.countTokens());
	}
	*/
	
	
	//String buff_sess1/String tokenizer 4
	public static void display(String teamList){
		StringTokenizer st = new StringTokenizer(teamList, ",");
		System.out.println("Player Name : " + st.nextToken());
	}
	
}
