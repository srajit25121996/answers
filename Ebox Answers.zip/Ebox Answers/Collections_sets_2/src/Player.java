

public class Player implements Comparable<Player>{

	private String playerName;
	private String skill;
	private Long capNumber;
	
	//Constructor (String, String, Long)
	public Player(String playerName, String skill, Long capNumber) {
		super();
		this.playerName = playerName;
		this.skill = skill;
		this.capNumber = capNumber;
	}

	//Getters and setters
	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public Long getCapNumber() {
		return capNumber;
	}

	public void setCapNumber(Long capNumber) {
		this.capNumber = capNumber;
	}

	
	}

	@Override
	public String toString() {
		return playerName + "-" + capNumber;
	}


      //Compare based on cap number
	public int compareTo(Player p) {
		
		// TODO Auto-generated method stub
		return (int) (this.capNumber - p.getCapNumber());
	
	
}
