import java.text.SimpleDateFormat;
import java.util.Date;

public class Match implements Comparable{

	Date matchDate;
	String teamOne;
	String teamTwo;
	
	//Constructor (Date, String, String)
	public Match(Date matchDate, String teamOne, String teamTwo) {
		super();
		this.matchDate = matchDate;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
	}
	
	//Getters and Setters
	public Date getMatchDate() {
		return matchDate;
	}
	public void setMatchDate(Date matchDate) {
		this.matchDate = matchDate;
	}
	public String getTeamOne() {
		return teamOne;
	}
	public void setTeamOne(String teamOne) {
		this.teamOne = teamOne;
	}
	public String getTeamTwo() {
		return teamTwo;
	}
	public void setTeamTwo(String teamTwo) {
		this.teamTwo = teamTwo;
	}

	@Override
	public int compareTo(Object m) {
		// TODO Auto-generated method stub
		int precedence = this.matchDate.compareTo(((Match) m).getMatchDate());
		return ((-1) *precedence);
	}

	@Override
	public String toString() {
		
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		String str = "Team 1 " + teamOne + "\nTeam 2 " + teamTwo + "\nMatch held on " + sdf.format(matchDate);
		return str;
	}
	
	
}
