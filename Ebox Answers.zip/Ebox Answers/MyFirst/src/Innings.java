
public class Innings {

	String battingTeam;
	Long runs;
	
	//Constructor (String, Long)
	public Innings(String battingTeam, Long runs){
		
		this.battingTeam = battingTeam;
		this.runs = runs;
	}
	
	//empty Construcor
	public Innings(){

	}
	//Setters
	public void setBattingTeam(String battingTeam){
		this.battingTeam = battingTeam;
	}
	public void setRuns(Long runs){
		this.runs = runs;
	}
	
	//Getters
	public String getBattingTeam(){
		return battingTeam;
	}
	public Long getRuns(){
		return runs;
	}

	@Override
	public String toString() {
		return battingTeam + " -- " + runs;
	}
	
	
}
