
public class Match {

	private String date;
	private String teamone;
	private String teamtwo;
	private Venue venue;
	
	
	//Constructor(String X3, Venue)
	public Match(String date, String teamone, String teamtwo, Venue venue) {
		super();
		this.date = date;
		this.teamone = teamone;
		this.teamtwo = teamtwo;
		this.venue = venue;
	}
	//Empty Constructor
	public Match(){};
	
	//Getters and Setters
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTeamone() {
		return teamone;
	}
	public void setTeamone(String teamone) {
		this.teamone = teamone;
	}
	public String getTeamtwo() {
		return teamtwo;
	}
	public void setTeamtwo(String teamtwo) {
		this.teamtwo = teamtwo;
	}
	public Venue getVenue() {
		return venue;
	}
	public void setVenue(Venue venue) {
		this.venue = venue;
	}
	
	//Overriding toString()
	@Override
	public String toString() {
		return String.format("%-15s%-30s%s", date, teamone, teamtwo);
	}
	
}


