
public class CityBO {
	
	
	public City createCity(String data){
		City c = new City(data);
		return c;
	}
}
