
public class MatchBO {
	
	//Creating object of Match type
	public Match createMatch(String data, Venue[] venueList){
		
		String[] matchDetails = data.split(",");
		
		
		//Initializing Match
		Match m = new Match();
		m.setDate(matchDetails[0]);
		m.setTeamone(matchDetails[1]);
		m.setTeamtwo(matchDetails[2]);
		//Setting venue
		for(Venue v: venueList){
			if(matchDetails[3].equals(v.getName()))
				m.setVenue(v);
		}
		
		return m;
	}
	
	//Finding a Match venue based on match date
	public void findVenue(String matchDate, Match[] matchList){
		
		boolean matchFound = false;
		
		for (Match m: matchList){
			if(m.getDate().equals(matchDate)){
				System.out.println("Match was held at " + m.getVenue().getName());
				matchFound = true;
			}
				
		}
		if(matchFound == false)
			System.out.println("Match not found");
	}
	
	//Finding all matches in a given venue
	public void findAllMatchesInGivenVenue(String venueName, Match[] matchList){
		
		boolean matchFound = false;
		
		//Result syntax
		System.out.println("Matches in venue " + venueName + " are");
		System.out.println(String.format("%-15s%-15s%s", "Date", "TeamOne", "TeamTwo"));
		
		for (Match m: matchList){
			if(m.getVenue().getName().equals(venueName)){
				System.out.println(String.format("%-15s%-15s%s", m.getDate(), m.getTeamone(), m.getTeamtwo()));
				matchFound = true;
			}
				
		}
		
		if(matchFound == false)
			System.out.println("Match not found");
	}

}
